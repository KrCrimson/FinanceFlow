// Pruebas de integración con MongoDB real en memoria (sin mocks de base de datos).
// Se ejecutan con: npm run test:integration
module.exports = {
  testEnvironment: 'node',
  testMatch: ['**/integration/**/*.itest.js'],
  testTimeout: 60000,
};
