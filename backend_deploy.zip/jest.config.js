// jest.config.js para soporte ESM
export default {
  testEnvironment: 'node',
  setupFilesAfterEnv: ['./jest.setup.js'],
  // Umbral mínimo de cobertura (se exige con `npm run test:ci`). Meta del curso: >= 70 % de líneas.
  coverageThreshold: {
    global: { statements: 70, branches: 55, functions: 60, lines: 70 },
  },
};
