const errorHandler = require('../middlewares/errorHandler');

const crearRes = () => {
  const res = {};
  res.status = jest.fn().mockReturnValue(res);
  res.json = jest.fn().mockReturnValue(res);
  return res;
};
const req = { method: 'POST', path: '/api/test' };

describe('errorHandler', () => {
  const entornoOriginal = process.env.NODE_ENV;

  beforeEach(() => {
    jest.spyOn(console, 'error').mockImplementation(() => {});
  });
  afterEach(() => {
    process.env.NODE_ENV = entornoOriginal;
    jest.restoreAllMocks();
  });

  it('responde 400 ante un JSON mal formado', () => {
    const err = Object.assign(new SyntaxError('Unexpected token'), { status: 400, body: '{' });
    const res = crearRes();
    errorHandler(err, req, res, jest.fn());
    expect(res.status).toHaveBeenCalledWith(400);
    expect(res.json).toHaveBeenCalledWith({ error: 'Formato JSON inválido en la solicitud' });
  });

  it('responde 400 ante un error de validación y muestra los detalles fuera de producción', () => {
    process.env.NODE_ENV = 'test';
    const err = { name: 'ValidationError', errors: { monto: { message: 'monto requerido' } } };
    const res = crearRes();
    errorHandler(err, req, res, jest.fn());
    expect(res.status).toHaveBeenCalledWith(400);
    expect(res.json).toHaveBeenCalledWith({
      error: 'Error de validación de datos',
      detalles: ['monto requerido'],
    });
  });

  it('en producción no filtra los detalles internos de validación', () => {
    process.env.NODE_ENV = 'production';
    const err = { name: 'ValidationError', errors: { monto: { message: 'monto requerido' } } };
    const res = crearRes();
    errorHandler(err, req, res, jest.fn());
    expect(res.json.mock.calls[0][0].detalles).toBeUndefined();
  });

  it('responde 400 ante un CastError sin revelar el esquema', () => {
    const res = crearRes();
    errorHandler({ name: 'CastError', message: 'Cast to ObjectId failed for model Usuario' }, req, res, jest.fn());
    expect(res.status).toHaveBeenCalledWith(400);
    expect(res.json).toHaveBeenCalledWith({ error: 'Identificador o formato de parámetro inválido' });
  });

  it.each(['JsonWebTokenError', 'TokenExpiredError'])('responde 401 ante %s', (name) => {
    const res = crearRes();
    errorHandler({ name, message: 'x' }, req, res, jest.fn());
    expect(res.status).toHaveBeenCalledWith(401);
    expect(res.json).toHaveBeenCalledWith({ error: 'Sesión inválida o expirada' });
  });

  it('responde 403 ante un error de CORS', () => {
    const res = crearRes();
    errorHandler(new Error('Not allowed by CORS'), req, res, jest.fn());
    expect(res.status).toHaveBeenCalledWith(403);
  });

  it('usa el status del error y su mensaje fuera de producción', () => {
    process.env.NODE_ENV = 'test';
    const res = crearRes();
    errorHandler(Object.assign(new Error('no existe'), { statusCode: 404 }), req, res, jest.fn());
    expect(res.status).toHaveBeenCalledWith(404);
    expect(res.json).toHaveBeenCalledWith({ error: 'no existe' });
  });

  it('en producción un error inesperado devuelve 500 con mensaje genérico', () => {
    process.env.NODE_ENV = 'production';
    const res = crearRes();
    errorHandler(new Error('detalle interno con datos sensibles'), req, res, jest.fn());
    expect(res.status).toHaveBeenCalledWith(500);
    expect(res.json).toHaveBeenCalledWith({ error: 'Error interno del servidor' });
  });
});
